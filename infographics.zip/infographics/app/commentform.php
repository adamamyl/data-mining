<style type="text/css">
#comment_form{
    overflow-y:hidden;
    border:none;
    height: 100%;
    width:100%;

}

</style>

<iframe src="discus.html" id="comment_form" scrolling="no"></iframe>